from kivymd.app import MDApp
from kivy.uix.screenmanager import ScreenManager
from kivy.lang import Builder
import paho.mqtt.client as mqtt
from kivy.core.window import Window 
from kivy.uix.label import Label
import MySQLdb
from pythonping import ping
from kivy.uix.popup import Popup
from kivymd.uix.scrollview import MDScrollView
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from kivymd.uix.menu import MDDropdownMenu
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.properties import StringProperty
from kivy.app import App
from kivymd.uix.textfield import MDTextField
from kivy.uix.label import Label








client = mqtt.Client()
Kwh = []
Precio_Plan = []
ConsumoM =[]


class LoginScreen(Screen):
    pass

class Ui(Screen):
    pass

class RegisterScreen(Screen):
    pass


class Controles(Screen):
    pass

class Graficas(Screen):
    pass

class Usuario(Screen):
    pass


Builder.load_string("""
<Consejos>:
    MDScreen:
        name: 'Consejos'
        MDBoxLayout:
            orientation: 'vertical'
            padding: ['10dp', '10dp', '10dp', '145dp']  # Ajusta el padding para dejar espacio al botón
            spacing: '10dp'

            MDCard:
                orientation: 'vertical'
                size_hint: 1, None
                height: dp(100)
                md_bg_color: 0.2, 0.8, 0.5, 1

                MDTextField:
                    id: consejos_textfield
                    hint_text: "Mensaje de consejos"
                    multiline: True
                    font_size: 20
                    readonly: True  # Establece esta propiedad en True
                    disabled: True
""")

class Consejos(Screen):

    def __init__(self, **kwargs):
        super(Consejos, self).__init__(**kwargs)
        main_app = App.get_running_app()
        self.conexion = main_app.Conexion_mysql()

    def on_enter(self):
        self.obtener_consejos()

    def obtener_consejos(self):
        self.check_energy_consumption()

    def get_current_kwh_value(self):
        main_app = App.get_running_app()
        connection = main_app.Conexion_mysql()
        if connection is None:
            print("No se pudo establecer la conexión a la base de datos.")
            return 0.0

        try:
            cursor = connection.cursor()
            cursor.execute("SELECT Kwh FROM Dato")
            result = cursor.fetchone()

            if result:
                current_kwh = result[0]
                print(f"Valor actual de kWh: {current_kwh}")
                return current_kwh
            else:
                return 0.0

        except Exception as e:
            print("Error al obtener el valor de kWh:", e)
            return 0.0
        finally:
            cursor.close()

    def check_energy_consumption(self):
        print("Función check_energy_consumption se está ejecutando")
        
        # Accede directamente al widget MDTextField
        consejos_textfield = self.ids.consejos_textfield

        if self.get_current_kwh_value() > 100:
            print("El consumo de energía es elevado. ¡Debes tomar medidas!")
            mensaje = "El consumo de energía es elevado. ¡Debes tomar medidas!"
        else:
            mensaje = "El consumo de energía es normal."

        # Actualiza el texto del widget MDTextField
        consejos_textfield.text = mensaje

        print(mensaje)

class Notificaciones(Screen):
    pass

class Servicios(Screen):
    pass

class MainApp(MDApp):
    
    selected_ute_option = ""  # Variable para almacenar la opción seleccionada
    dialog = None
    plan_ute_mapping = {
        "Opción 1": 1,
        "Opción 2": 2,
        "Opción 3": 3,
    }

    def build(self, *args):
        self.theme_cls.theme_style = 'Light'
        self.theme_cls.primary_palette = 'Teal'
        Builder.load_file('design.kv')
        #Window.size = (720 , 1190)
        self.client = mqtt.Client()
        self.ConsumoD = 0 
        self.ConsumoM = [] 
        Clock.schedule_once(self.actualizar_variable, 0) 

        
   
       
        sm = ScreenManager()
        
            
            # Agrega tus pantallas al ScreenManager
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(RegisterScreen(name='register'))
        sm.add_widget(Ui(name='Screen_Menu'))
        sm.add_widget(Controles(name='screen1'))
        sm.add_widget(Graficas(name='screen2'))
        sm.add_widget(Usuario(name='screen3'))
        sm.add_widget(Consejos(name='screen4'))
        sm.add_widget(Notificaciones(name='screen5'))
        sm.add_widget(Servicios(name='screen6'))
 



        
            
        return sm
        
    
    
    def Conexion_mysql(self):
        connection = None
        try:
            connection = MySQLdb.connect(
                host='127.0.0.1',
                user='root',
                password='hola',
                db='ec'
            )
            print("Conexión exitosa a MySQL")
            return connection
        except Exception as e:
            print("Error al conectar a MySQL:", e)
            return None
        
#=========================================================================================================
#Login Registrar

    def login(self):
        username = self.root.get_screen('login').ids.user.text
        password = self.root.get_screen('login').ids.password.text
        connection = self.Conexion_mysql()
        try:
            
            cursor = connection.cursor()

            # Consulta SQL para verificar si el usuario y la contraseña coinciden
            select_query = "SELECT * FROM Usuario WHERE NombreUsuario = %s AND Contrasenia = %s"
            cursor.execute(select_query, (username, password))
            user_data = cursor.fetchone()  # Obtener el primer resultado

            if user_data:
                # Usuario y contraseña válidos, permitir el acceso
                print(f"Bienvenido, {username}!")
                self.root.current = 'Screen_Menu'
                
             

            else:
                # Usuario o contraseña incorrectos, mostrar un mensaje de error
                self.show_message("Error de inicio de sesión", "Nombre de usuario o contraseña incorrectos.")

            # Cerrar la conexión
            cursor.close()
            connection.close()

        except Exception as e:
            print("Error de inicio de sesión:", str(e))
            self.show_message("Error", "Ocurrió un error al iniciar sesión.")

    def show_ute_menu(self, button):
        menu_items = [{"viewclass": "OneLineListItem", "text": "Opción 1"}, {"viewclass": "OneLineListItem", "text": "Opción 2"}, {"viewclass": "OneLineListItem", "text": "Opción 3"}]

        self.ute_menu = MDDropdownMenu(
            caller=button,
            items=menu_items,
            width_mult=4,
        )

        # Enlazar la función de selección de opción al evento on_release del DropDownItem
        for item in menu_items:
            item["on_release"] = lambda x=item: self.ute_option_selected(x["text"])

        self.ute_menu.open()

    def ute_option_selected(self, option):
        # Almacenar la opción seleccionada y actualizar el texto del MDDropDownItem
        self.selected_ute_option = option
        self.root.current_screen.ids.ute_dropdown.text = option

    def register(self):
        # Recopila la información de registro aquí y realiza las acciones necesarias
        name = self.root.get_screen('register').ids.register_user.text
        email = self.root.get_screen('register').ids.register_email.text
        password = self.root.get_screen('register').ids.register_password.text
        # Plan de UTE: self.selected_ute_option

        print(f"Nombre: {name}, Email: {email}, Password: {password}, Plan de UTE: {self.selected_ute_option}")

  
        selected_option = self.selected_ute_option  # Obtiene la opción seleccionada del menú

        # Obtén el valor correspondiente a la opción seleccionada
        plan_ute = self.plan_ute_mapping.get(selected_option, None)

        if plan_ute is None:
            self.show_message("Error", "Opción de UTE no válida.")
            return

        # Realizar la inserción en la base de datos
        connection = self.Conexion_mysql()
        try:
            cursor = connection.cursor()

            # Insertar el nuevo usuario en la tabla Usuario
            insert_query = "INSERT INTO Usuario (Contrasenia, Correo, NombreUsuario, PlanUteID) VALUES (%s, %s, %s, %s)"
            cursor.execute(insert_query, (password, email, name, plan_ute))
            connection.commit()

            # Cerrar la conexión
            cursor.close()
            connection.close()

            # Mostrar un mensaje de éxito
            self.show_message("Registro exitoso", "El usuario ha sido registrado exitosamente.")

        except Exception as e:
            print("Error al registrar el usuario:", str(e))
            self.show_message("Error", "Ocurrió un error al registrar el usuario.")


    def show_message(self, title, text):
        if not self.dialog:
            self.dialog = MDDialog(
                title=title,
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        text_color=self.theme_cls.primary_color,
                        on_release=self.close_dialog
                    ),
                ]
            )
        self.dialog.open()

    def close_dialog(self, *args):
        self.dialog.dismiss()
        self.dialog = None
        
#==========================================================================================================
#Menu
        
    def Select_Datos_Consumo(self):
        connection = self.Conexion_mysql()
        Kwh, Precio_Plan = [], []
        if connection is not None:
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT Dato.Kwh, Plan_UTE.PrecioP FROM Dato, Plan_UTE where UsuarioDispo = '3';")
                resultados = cursor.fetchall()
                for fila in resultados:
                    Kwh.append(fila[-1])
                    Precio_Plan.append(fila[1])
                    print(Kwh)
                    print(Precio_Plan)
            except Exception as e:
                print("Error al ejecutar la consulta:", e)
            finally:
                cursor.close()
                connection.close()
        return Kwh, Precio_Plan


    def actualizar_variable(self, *args):
        
        try:
            Kwh, Precio_Plan = self.Select_Datos_Consumo()
            self.ConsumoD += sum(Kwh)
            PrecioD = Kwh[-1] * Precio_Plan[-1]
            self.ConsumoM.append(sum(Kwh))  # Modifica esta línea
            

            self.root.get_screen('Screen_Menu').ids.Consumo_dia.text = f"Consumo Kwh/Día: {self.ConsumoD}"
            self.root.get_screen('Screen_Menu').ids.Precio_dia.text = f"Precio Kwh/Día: {PrecioD}"
            self.root.get_screen('Screen_Menu').ids.Consumo_mes.text = f"Consumo Kwh/Mes: {sum(self.ConsumoM)}"
            self.root.get_screen('Screen_Menu').ids.Precio_mes.text = f"Precio Kwh/Mes: {sum(self.ConsumoM) * Precio_Plan[-1]}"
        except Exception as e:
                print("Error al ejecutar la consulta:", e)

    def on_start(self):
        Clock.schedule_interval(self.actualizar_variable, 3600)

    def on_start_Mes(self):
        Clock.schedule_interval(self.actualizar_consumoM, 86400)

    def actualizar_consumoM(self, *args):
        self.ConsumoM += sum(self.ConsumoD)
    
    def on_start_Limpiar_consumoM(self):
        Clock.schedule_interval(self.Limpiar_consumoM, 2,592,000)
        
    def on_start_Limpiar_consumoD(self):
        Clock.schedule_interval(self.Limpiar_consumoD, 86400)
        
    def Limpiar_consumoM(self, *args):
        self.ConsumoM = []  # Limpiar la lista, no asignar una nueva
        print("Consumo Mensual limpiado")

    def Limpiar_consumoD(self, *args):
        self.ConsumoD = 0  # Limpiar el valor, no asignar una nueva lista
        print("Consumo Diario limpiado")
    
    
    def button_action_Controles(self, button_id):
        if button_id == 1:
            self.root.current = 'screen1'
    
   
            
    def button_action_Consejos(self, button_id):
        if button_id == 1:
            self.root.current = 'screen4'
    
    def button_action_Notificaciones(self, button_id):
        if button_id == 1:
            self.root.current = 'screen5'
    
    def button_action_Servicios(self, button_id):
        if button_id == 1:
            self.root.current = 'screen6'
            
    def button_action_Regresar(self, button_id):
        if button_id == 1:
            self.root.current = 'Screen_Menu'
        
#=====================================================================================
# Pagina Graficas

    def actualizar_grafica(self,data):
        dias_semana = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes']
        precios_uruguayos = [1, 2, 3, 2.5, 1.8]  # Precio en pesos uruguayos
        watts = [100, 150, 120, 180, 200]  # Consumo en watts

        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(6, 8))
        plt.suptitle('Gráfica del Dispositivo', fontsize=32, y=0.98)
        ax1.bar(dias_semana, precios_uruguayos, color='blue')
        ax1.set_title('Precio en Pesos Uruguayos por Día de la Semana')
        ax1.set_xlabel('Día de la Semana')
        ax1.set_ylabel('Precio (en pesos uruguayos)')

        ax2.bar(dias_semana, watts, color='green')
        ax2.set_title('Consumo en Watts por Día de la Semana')
        ax2.set_xlabel('Día de la Semana')
        ax2.set_ylabel('Consumo (en watts)')

        manager = plt.get_current_fig_manager()
        manager.toolbar.pack_forget()

        plt.tight_layout()
        plt.show()

    
    def button_action_Graficas(self, button_id):
        if button_id == 1:
            self.actualizar_grafica(data=1)
            
           

        
    
#==================================================================================== 

# Pagina Controles

    def publish_mqtt_message(self, message):
        self.client.connect("192.168.175.52", 1883, 1)
        self.client.publish("controlar_reles", message)
        
    
    def switch_changed_1(self, active):
        try:
            if active:
                print("Switch 1 encendido")
                self.publish_mqtt_message("1**")
            else:
                print("Switch 1 apagado")
                self.publish_mqtt_message("0**")
        except Exception as e:
            print("Error al publicar:", e)


    def switch_changed_2(self, active):
        try:
            if active:
                print("Switch 2 encendido")
                self.publish_mqtt_message("*1*")
            else:
                print("Switch 2 apagado")
                self.publish_mqtt_message("*0*")
        except Exception as e:
            print("Error al publicar:", e)

    def switch_changed_3(self, active):
        try:
            if active:
                print("Switch 3 encendido")
                self.publish_mqtt_message("**1")
            else:
                print("Switch 3 apagado")
                self.publish_mqtt_message("**0")
        except Exception as e:
            print("Error al publicar:", e)
            
    def start(self):
        self.client.loop_start()

#====================================================================================

# Pagina Dispositivos

    
    def show_data_popup(self, data):
        scroll_view = MDScrollView()
        content = Label(text=data)  
        content.bind(size=content.setter('text_size'))  
        scroll_view.add_widget(content)

        popup = Popup(title="Datos de la consulta SELECT", content=scroll_view, size_hint=(None, None), size=(720, 1000))
        popup.open()
         
    def show_message(self, title, text):
        from kivymd.toast import toast
        toast(text)

    def button_action(self, button_id):
        if button_id == 1:
            # Realizar ping al 192.168.169.74
            response = ping('192.168.175.74', count=2)
            if response.success():
                self.show_message("Ping exitoso", "El dispositivo responde.")
            else:
                self.show_message("Ping fallido", "El dispositivo no responde.")

        elif button_id == 2:
            # Realizar ping al 192.168.169.2
            response = ping('192.168.175.52', count=2)
            if response.success():
                self.show_message("Ping exitoso", "El servidor responde.")
            else:
                self.show_message("Ping fallido", "El servidor no responde.")

        elif button_id == 3:
            print("Botón 'Datos Generales' presionado")
            # Intenta conectar a MySQL
            connection = self.Conexion_mysql()
            if connection is not None:
                try:
                    cursor = connection.cursor()
                    cursor.execute("SELECT Kwh ,Fecha ,Reles1, Reles2, Reles3 FROM Dato where UsuarioDispo = '3';")
                    # Obtener todos los resultados de la consulta
                    resultados = cursor.fetchall()
                    # Crear una cadena de texto con los resultados
                    data_text = ""
                    for fila in resultados:
                        data_text += str(fila) + "\n"
                    # Llamar a la función para mostrar la ventana emergente con los datos
                    self.show_data_popup(data_text)
                except Exception as e:
                    print("Error al ejecutar la consulta:", e)
                finally:
                    # Cerrar el cursor
                    cursor.close()
                    # Cerrar la conexión
                    connection.close()






#====================================================================================
#Pagina Usuario

    def button_action_datosUsuario(self, button_id):
        if button_id == 1:
            self.Select_Datos_Usuarios()
            NombreU, CorreoU, DispoU, NombrePU = self.Select_Datos_Usuarios()
            self.actualizar_variable_Usuario(NombreU, CorreoU, DispoU, NombrePU)
            self.root.current = 'screen3'

    def Select_Datos_Usuarios(self):
        NombreU=[]
        CorreoU=[]
        DispoU=[]
        NombrePU=[]
        connection = self.Conexion_mysql()
        if connection is not None:
            print("Conexión a MySQL establecida correctamente.")
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT Usuario.NombreUsuario, Usuario.Correo, Dato.UsuarioDispo, Plan_UTE.NombreP FROM Dato INNER JOIN Usuario ON Dato.NumDatoDispo = Usuario.CodigoUsuario INNER JOIN Plan_UTE ON Dato.NumDatoDispo = Plan_UTE.codigoP WHERE Plan_UTE.CodigoP = 3;")
                resultados = cursor.fetchall()
                for fila in resultados:
                    NombreU.append(fila[0])
                    CorreoU.append(fila[1])
                    DispoU.append(fila[2])
                    NombrePU.append(fila[3])
                    


            except Exception as e:
                print("Error al ejecutar la consulta:", e)
            finally:
                cursor.close()
                connection.close()
                print("NombreU:", NombreU)
                print("CorreoU:", CorreoU)
                print("DispoU:", DispoU)
                print("NombrePU:", NombrePU)
        return NombreU, CorreoU, DispoU, NombrePU,


    def actualizar_variable_Usuario(self,  NombreU, CorreoU, DispoU, NombrePU):
        if NombreU and CorreoU and DispoU and NombrePU:

            self.root.get_screen('screen3').ids.Usuario.text = f"  Usuario : {NombreU[-1]}"
            self.root.get_screen('screen3').ids.Plan_UTE.text = f"      Plan de UTE : {NombrePU[-1]}"
            self.root.get_screen('screen3').ids.CorreoE.text = f"      Correo electronico : {CorreoU[-1]}"
            self.root.get_screen('screen3').ids.NuemeroD.text = f"      Numero de dispocitivo :{DispoU[-1]}"


#====================================================================================
#Pagina consejos




   
if __name__ == "__main__":
    MainApp().run()


